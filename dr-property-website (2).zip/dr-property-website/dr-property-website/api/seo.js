// Serves /sitemap.xml, /robots.txt, /llms.txt from values saved by the dashboard SEO page.
module.exports=async(req,res)=>{
 const map={sitemap:['sitemap_xml','application/xml'],robots:['robots_txt','text/plain'],llms:['llms_txt','text/plain']};
 const m=map[req.query.t];if(!m)return res.status(404).end('Not found');
 try{const r=await fetch(`${process.env.SUPABASE_URL}/rest/v1/site_settings?key=eq.${m[0]}&select=value`,{headers:{apikey:process.env.SUPABASE_ANON_KEY}});
 const j=await r.json();if(!j[0]||!j[0].value)return res.status(404).end('Generate this file from Admin → SEO first');
 res.setHeader('Content-Type',m[1]+'; charset=utf-8');res.setHeader('Cache-Control','s-maxage=300,stale-while-revalidate');res.end(j[0].value)}catch(e){res.status(500).end('Error')}};
